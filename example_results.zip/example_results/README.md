# Workshop example data / Dados de exemplo

EN: These files are a teaching copy of a YouTube extraction. Account and comment identifiers have been replaced with consistent codes across all CSV files. Display names have been replaced, comment text is a fictitious placeholder, and comment publication/update timestamps have been removed. Blank account IDs remain blank and must be excluded from user sets; display names are never used to infer identity. Video metadata and numerical counts are preserved. The files retain observed account overlaps, but do not support comment-content analysis. This transformation is not a guarantee of complete anonymity. No lookup table linking the codes to original IDs is included. Optional images are copied without modification and must be checked separately. Non-root source folders receive generic names.

PT-PT: Estes ficheiros são uma cópia didática de uma extração do YouTube. Os identificadores de contas e comentários foram substituídos por códigos consistentes em todos os CSV. Os nomes foram substituídos, os textos dos comentários são exemplos fictícios e as datas de publicação/atualização dos comentários foram removidas. Os identificadores de conta em falta permanecem vazios e devem ser excluídos dos conjuntos de utilizadores. Os metadados dos vídeos e as contagens foram preservados. A transformação mantém as coincidências observadas entre contas, mas não permite analisar o conteúdo dos comentários nem garante anonimato completo. Não é incluída uma tabela de correspondências com os identificadores originais. As imagens opcionais são copiadas sem alterações e devem ser verificadas separadamente.

## Files / Ficheiros
- 9d1Y6z-bjRU_comments.csv: 100 rows / linhas
- 9d1Y6z-bjRU_users.csv: 85 rows / linhas
- _jo64fisA4Q_comments.csv: 100 rows / linhas
- _jo64fisA4Q_users.csv: 84 rows / linhas
- dx6rYE3WKJU_comments.csv: 100 rows / linhas
- dx6rYE3WKJU_users.csv: 94 rows / linhas
- l5KPBqNe3Cc_comments.csv: 100 rows / linhas
- l5KPBqNe3Cc_users.csv: 94 rows / linhas
- xBCLXnwn-mA_comments.csv: 100 rows / linhas
- xBCLXnwn-mA_users.csv: 92 rows / linhas

See extraction_log.csv for per-video extraction status. limit_reached indicates that the configured comment limit was reached; the collection is not exhaustive.
